import {
  ArrowRight,
  BadgeCheck,
  CalendarDays,
  CircleHelp,
  Construction,
  Gamepad2,
  Grid2X2,
  KeyRound,
  LayoutDashboard,
  LockKeyhole,
  Monitor,
  Radio,
  Settings,
  Sparkles,
  Tv,
  Users,
} from 'lucide-react';
import {
  Link,
  Navigate,
  Route,
  Routes,
} from 'react-router-dom';

import AdminPage from './admin/AdminPage';
import DisplayPage from './display/DisplayPage';
import TriviaPrototype from './trivia/TriviaPrototype';

import './App.css';

/* ==========================================================
   APP 001 - TVM MODULE MODEL
   Central registry for the Television Venue Media suite.
   ========================================================== */

type ModuleStatus = 'active' | 'development' | 'planned';

type TvmModule = {
  id: string;
  name: string;
  category: string;
  description: string;
  icon: typeof Tv;
  status: ModuleStatus;
  primaryLabel?: string;
  primaryTo?: string;
  secondaryLabel?: string;
  secondaryTo?: string;
};

const modules: TvmModule[] = [
  {
    id: 'boards',
    name: 'TVM Boards',
    category: 'Menus & Digital Displays',
    description:
      'Create and manage browser-based menu boards, pricing, specials, layouts, and venue display screens.',
    icon: Monitor,
    status: 'active',
    primaryLabel: 'Open Boards',
    primaryTo: '/menu/admin',
    secondaryLabel: 'View Display',
    secondaryTo: '/menu/display/main',
  },
  {
    id: 'trivia',
    name: 'TVM Trivia',
    category: 'Live Venue Trivia',
    description:
      'Run host-controlled trivia sessions with shared TV questions, four-digit join codes, mobile answers, and live scoring.',
    icon: CircleHelp,
    status: 'development',
    primaryLabel: 'Open Trivia',
    primaryTo: '/trivia',
  },
  {
    id: 'bingo',
    name: 'TVM Bingo',
    category: 'Interactive Games',
    description:
      'A future module for traditional bingo, music bingo, venue-hosted rounds, and browser-based player cards.',
    icon: Grid2X2,
    status: 'planned',
  },
  {
    id: 'live',
    name: 'TVM Live',
    category: 'Audience Interaction',
    description:
      'Live polls, voting, song guessing, crowd games, contests, and other real-time audience experiences.',
    icon: Radio,
    status: 'planned',
  },
  {
    id: 'events',
    name: 'TVM Events',
    category: 'Venue Promotions',
    description:
      'Schedule event slides, promotions, announcements, recurring venue content, and time-based campaigns.',
    icon: CalendarDays,
    status: 'planned',
  },
  {
    id: 'games',
    name: 'TVM Games',
    category: 'Future Module',
    description:
      'Reserved for additional television-first venue games and interactive experiences built on the TVM platform.',
    icon: Gamepad2,
    status: 'planned',
  },
];

/* ==========================================================
   APP 002 - STATUS BADGE
   Licensing will eventually replace the temporary local state.
   ========================================================== */

function StatusBadge({ status }: { status: ModuleStatus }) {
  if (status === 'active') {
    return (
      <span className="module-status module-status--active">
        <BadgeCheck size={13} /> Active
      </span>
    );
  }

  if (status === 'development') {
    return (
      <span className="module-status module-status--development">
        <Construction size={13} /> In Development
      </span>
    );
  }

  return (
    <span className="module-status module-status--planned">
      <LockKeyhole size={13} /> Planned
    </span>
  );
}

/* ==========================================================
   APP 003 - MODULE TILE
   Main reusable launcher tile.
   ========================================================== */

function ModuleTile({ module }: { module: TvmModule }) {
  const Icon = module.icon;

  return (
    <article className={`module-tile module-tile--${module.status}`}>
      <div className="module-tile__header">
        <div className="module-tile__icon">
          <Icon size={23} />
        </div>
        <StatusBadge status={module.status} />
      </div>

      <div className="module-tile__body">
        <span className="module-tile__category">{module.category}</span>
        <h2>{module.name}</h2>
        <p>{module.description}</p>
      </div>

      <div className="module-tile__footer">
        {module.primaryTo && module.primaryLabel ? (
          <Link className="module-action module-action--primary" to={module.primaryTo}>
            {module.primaryLabel}
            <ArrowRight size={15} />
          </Link>
        ) : (
          <span className="module-action module-action--disabled">
            Not yet available
          </span>
        )}

        {module.secondaryTo && module.secondaryLabel && (
          <Link className="module-action module-action--secondary" to={module.secondaryTo}>
            {module.secondaryLabel}
          </Link>
        )}
      </div>
    </article>
  );
}

/* ==========================================================
   APP 004 - TVM MAIN MODULE LAUNCHER
   Root application home at `/`.
   ========================================================== */

function TvmHomePage() {
  const activeCount = modules.filter((module) => module.status === 'active').length;
  const developmentCount = modules.filter((module) => module.status === 'development').length;

  return (
    <div className="tvm-app-shell">
      <header className="tvm-topbar">
        <Link className="tvm-logo" to="/" aria-label="TVM home">
          <span className="tvm-logo__mark">TVM</span>
          <span className="tvm-logo__text">
            <strong>Television Venue Media</strong>
            <small>OneTime Labs</small>
          </span>
        </Link>

        <div className="tvm-topbar__actions">
          <a
            className="topbar-button"
            href="https://licensing.onetimelabs.net"
            target="_blank"
            rel="noreferrer"
          >
            <KeyRound size={14} />
            Licensing
          </a>
          <button className="topbar-icon-button" type="button" aria-label="TVM settings">
            <Settings size={16} />
          </button>
        </div>
      </header>

      <main className="tvm-main">
        {/* ==================================================
            APP 005 - PAGE HEADING / PLATFORM SUMMARY
            ================================================== */}
        <section className="launcher-heading">
          <div>
            <span className="launcher-kicker">
              <LayoutDashboard size={14} /> TVM Module Console
            </span>
            <h1>Choose a module.</h1>
            <p>
              Television Venue Media is a modular venue platform. Each product shares the same
              TVM organization, venue, display, database, and licensing foundation.
            </p>
          </div>

          <div className="platform-summary" aria-label="TVM platform summary">
            <div>
              <strong>{modules.length}</strong>
              <span>Modules</span>
            </div>
            <div>
              <strong>{activeCount}</strong>
              <span>Active</span>
            </div>
            <div>
              <strong>{developmentCount}</strong>
              <span>In Development</span>
            </div>
          </div>
        </section>

        {/* ==================================================
            APP 006 - MODULE GRID
            ================================================== */}
        <section className="module-section" aria-labelledby="module-heading">
          <div className="section-label-row">
            <div>
              <span>TVM PRODUCTS</span>
              <strong id="module-heading">Modules</strong>
            </div>
            <small>Access will ultimately be controlled by OneTime Labs Licensing.</small>
          </div>

          <div className="module-grid">
            {modules.map((module) => (
              <ModuleTile key={module.id} module={module} />
            ))}
          </div>
        </section>

        {/* ==================================================
            APP 007 - PLATFORM FOUNDATION
            ================================================== */}
        <section className="foundation-bar">
          <div className="foundation-bar__title">
            <Sparkles size={15} />
            <div>
              <strong>Shared TVM Platform</strong>
              <span>One backend. Multiple venue products.</span>
            </div>
          </div>

          <div className="foundation-bar__items">
            <span><Users size={14} /> Organizations & Venues</span>
            <span><Tv size={14} /> Registered Displays</span>
            <span><KeyRound size={14} /> Module Licensing</span>
          </div>
        </section>
      </main>

      <footer className="tvm-footer">
        <span>TVM · Television Venue Media</span>
        <span>Built by OneTime Labs</span>
      </footer>
    </div>
  );
}

/* ==========================================================
   APP 009 - ROUTING
   TVM umbrella + module routes + legacy compatibility.
   ========================================================== */

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<TvmHomePage />} />

      {/* TVM Boards / Menu module */}
      <Route path="/menu/admin" element={<AdminPage />} />
      <Route path="/menu/display/main" element={<DisplayPage screenId="screen-main" />} />
      <Route path="/menu/display/bar" element={<DisplayPage screenId="screen-bar" />} />

      {/* TVM Trivia prototype surfaces */}
      <Route path="/trivia" element={<TriviaPrototype view="host" />} />
      <Route path="/trivia/display" element={<TriviaPrototype view="display" />} />
      <Route path="/trivia/play" element={<TriviaPrototype view="player" />} />

      {/* Legacy routes */}
      <Route path="/admin" element={<Navigate to="/menu/admin" replace />} />
      <Route path="/display/main" element={<Navigate to="/menu/display/main" replace />} />
      <Route path="/display/bar" element={<Navigate to="/menu/display/bar" replace />} />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
